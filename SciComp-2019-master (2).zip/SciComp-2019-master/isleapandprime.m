function []= isleapandprime(year_of)

if isprime(year_of)==1 &&  isleapyear(year_of,0)==1
    disp('congratz! Prime and leap year!');
elseif isprime(year_of)==1 &&  isleapyear(year_of,0)==0
    disp('is a prime number, not a leap year')
else
    disp('Please try again! Not a prime and not a leap year');
    
end
