mat3 = {5 5 ; 6 6; 7 7; 8 8; 9 9};
char1 = "This is my first character array";
char2 = "this is not my last.";
temp = char1(1,5:9)
char3 = {char1 ". " char2};
disp(char3);
%% creating a cell aray
cell1 = {34, "thanks"}
cell2{2,10} = mat1;
cell{2,2} = NaN; 
%% structure array
student (1).name = 'John'
student(1).age = 23;
student(2).name = 'sabrina'
student(2).age = 27
student(1).grade = 85
student(2).grade = 90
when data get more complex
%% calling isleapyear
a = isleapyear(2024,1)
b = isleapyear(2000,1)